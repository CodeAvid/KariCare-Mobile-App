//
//  RequestType.swift
//  kariCare-ios
//
//  Created by akhigbe benjamin on 28/05/2021.
//

import Foundation

enum RequestType: String {
    case get = "GET"
    case post = "POST"
}
